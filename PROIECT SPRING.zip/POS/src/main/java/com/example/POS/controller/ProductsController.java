package com.example.POS.controller;

import com.example.POS.entity.Product;
import com.example.POS.service.ProductsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ProductsController {

    @Autowired
    private ProductsServiceImpl productsService;


    @RequestMapping("/products")
    public String getAllProducts(Model model){
        model.addAttribute("products",productsService.getAllProduct());
        return "products";
    }

    @RequestMapping("/products_admin")
    public String getAllProductsAdmin(Model model){
        model.addAttribute("products",productsService.getAllProduct());
        return "products_admin";
    }

    @GetMapping("/showNewProductForm")
    public String showNewProductForm(Model model) {
        Product product = new Product();
        model.addAttribute("product", product);
        return "new_product";
    }

    @PostMapping("/saveProduct")
    public String saveProduct(@ModelAttribute("product") Product product) {
        productsService.saveProduct(product);
        return "redirect:/products_admin";
    }

    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {

        Product product = productsService.getProductById(id);

        model.addAttribute("product", product);
        return "update_product";
    }

    @GetMapping("/deleteProduct/{id}")
    public String deleteEmployee(@PathVariable(value = "id") long id) {

        productsService.deleteProductById(id);
        return "redirect:/products_admin";
    }

}
