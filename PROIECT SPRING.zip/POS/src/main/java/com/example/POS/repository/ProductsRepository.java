package com.example.POS.repository;

import com.example.POS.entity.Product;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RestResource;

@RestResource(path="products", rel="product")
public interface ProductsRepository extends CrudRepository<Product,Long> {
}