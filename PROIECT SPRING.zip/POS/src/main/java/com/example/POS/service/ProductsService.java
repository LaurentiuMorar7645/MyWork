package com.example.POS.service;

import com.example.POS.entity.Product;

import java.util.List;

public interface ProductsService {

    List < Product > getAllProduct();
    void saveProduct(Product product);
    Product getProductById(long id);
    void deleteProductById(long id);

}
