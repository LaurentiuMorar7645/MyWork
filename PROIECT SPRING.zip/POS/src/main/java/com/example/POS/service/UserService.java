package com.example.POS.service;

import com.example.POS.entity.User;
import com.example.POS.web.UserRegistrationDto;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;



public interface UserService extends UserDetailsService {

    User findByEmail(String email);

    User save(UserRegistrationDto registration);

    UserDetails loadUserByUsername(String email);
}